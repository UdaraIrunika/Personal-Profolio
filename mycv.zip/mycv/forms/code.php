<?php


if(isset($_POST['sm_send']))
{

    $sm_name = $_POST['sm_name'];
    $sm_email = $_POST['sm_email'];
    $sm_tp = $_POST['sm_tp'];
    $sm_subject = $_POST['sm_subject'];
    $sm_messege = $_POST['sm_messege'];

            $connection = mysqli_connect("localhost","root","","profilo");
            $query = "INSERT INTO usermessesges(sm_name, sm_email, sm_tp, sm_subject, sm_messege) VALUES ('$sm_name','$sm_email','$sm_tp','$sm_subject','$sm_messege')";
            $query_run = mysqli_query($connection, $query);
            
            if($query_run)
            {
                $_SESSION['status'] = "Messege send";
                $_SESSION['status_code'] = "success";
                header('Location: index.php');
            }
            else 
            {
                $_SESSION['status'] = "Messege Not Send";
                $_SESSION['status_code'] = "error";
                header('Location: index.php');
            }
        
        }

  
if(isset($_POST['sm_mark']))
{
    $sm_id = $_POST['sm_edit_id'];
    $sm_name = $_POST['sm_uname'];
    $sm_messege = $_POST['sm_content'];
    $sm_status = $_POST['sm_status'];

    $connection = mysqli_connect("localhost","root","","profilo");
    $query = "UPDATE usermessesges SET sm_status='$sm_status' WHERE sm_id='$sm_id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "USERMESSEGE IS MARKED";
        $_SESSION['status_code'] = "success";
        header('Location: ../pro/admin/masseges.php'); 
    }
    else
    {
        $_SESSION['status'] = "USERMESSEGE IS NOT MARKED";
        $_SESSION['status_code'] = "error";
        header('Location: ../pro/admin/masseges.php'); 
    }
}



if(isset($_POST['sm_delete_btn']))
{
    $id = $_POST['sm_delete_id'];

    $connection = mysqli_connect("localhost","root","","profilo");
    $query = "DELETE FROM usermessesges WHERE sm_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "USER MESSEGES IS DELETED";
        $_SESSION['status_code'] = "success";
        header('Location: ../pro/admin/masseges.php'); 
    }
    else
    {
        $_SESSION['status'] = "USER MESSEGES IS NOT DELETED";       
        $_SESSION['status_code'] = "error";
        header('Location: ../pro/admin/masseges.php'); 
    }    
}
?>

<!--USERMASSEGES DELETE END-->

