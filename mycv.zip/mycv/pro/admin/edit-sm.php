<?php include_once('../template/admin/header.php'); ?>
<?php include_once('../template/admin/sidebar.php'); ?>
<?php include_once('../template/admin/navbar.php'); ?>












<body id="page-top">
 <!--Start Navigation Bar-->
 
  <!--Navigation Bar-->

  <div id="wrapper">

    <!-- Sidebar -->
    
    <!--End Sidebar-->
    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
       
        <hr>
        <div class="card">
        <div class="card-header">
          Mark Messege
        </div>
        <div class="card-body">
          <!--Add User Form-->
          <?php

            if(isset($_POST['sm_edata_btn']))
            {
                $id = $_POST['sm_edit_id'];
                $connection = mysqli_connect("localhost","root","","profilo");
                $query = "SELECT * FROM usermessesges WHERE sm_id='$id' ";
                $query_run = mysqli_query($connection, $query);

                foreach($query_run as $row)
                {
                    ?>
            <form action="../../forms/code.php" method="POST"> 

            <input type="hidden" name="sm_edit_id" value="<?php echo $row['sm_id'] ?>">

                <div class="form-group">
                    <label for="exampleInputEmail1">Client Name</label>
                    <input type="text" required readonly class="form-control" value="<?php echo $row['sm_name'] ?>" id="exampleInputEmail1" name="sm_uname">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Client Subject</label>
                    <input type="text" required readonly class="form-control" value="<?php echo $row['sm_subject'] ?>" id="exampleInputEmail1" name="sm_uname">
                </div>

                <div class="form-group">
                    <label for="exampleInputEmail1">Client Messege</label>
                    <textarea type="text" class="form-control" readonly placeholder = "Give Your Messege" id="exampleInputEmail1" name="sm_content"><?php echo $row['sm_messege'] ?></textarea>
                </div>

                <div class="form-group">
                <label for="exampleFormControlSelect1">Mark Status</label>
                <select class="form-control" name="sm_status" id="exampleFormControlSelect1">
                    <option>Mark</option>
                    <option>Pending</option>
                </select>
                </div>

                <button type="submit" name="sm_mark" class="btn btn-success">MARK</button>
            </form>
          <!-- End Form-->
          <?php
                }
            }
        ?>
        </div>
      </div>
       
      <hr>
     

    </div>
    <!-- /.content-wrapper -->

  </div>
  
  </div>

  
  </div>


















<?php include_once('../template/admin/footer.php'); ?>