<?php include_once('../template/admin/header.php'); ?>

<?php include_once('../template/admin/sidebar.php'); ?>

<?php include_once('../template/admin/navbar.php'); ?>





<!----------------------------------------------------------------------------------->

        <!-- DataTables Example -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa fa-comments"></i>
                Client Messeges</div>
          <div class="card-body">
            <div class="table-responsive">
            <?php
                $connection = mysqli_connect("localhost","root","","profilo");
                $query = "SELECT * FROM usermessesges";
                $query_run = mysqli_query($connection, $query);
          ?>
              <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>NAME</th>
                    <th>EMAIL</th>
                    <th>TELEPHONE</th>
                    <th>SUBJECT</th>
                    <th>MESSEGE</th>
                    <th>STATUS</th>
                    <th>ACTION</th>
                    <th>DELETE</th>
                  </tr>
                </thead>
                <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                {
            ?>
                <tbody>
                  <tr>
                    <td><?php  echo $row['sm_id']; ?></td>
                    <td><?php  echo $row['sm_name']; ?></td>
                    <td><?php  echo $row['sm_email']; ?></td>
                    <td><?php  echo $row['sm_tp']; ?></td>
                    <td><?php  echo $row['sm_subject']; ?></td>
                    <td><?php  echo $row['sm_messege']; ?></td>
                    <td><span class = "btn btn-outline-success"><i class="fa fa-cogs"></i><?php  echo $row['sm_status']; ?></span></td>
                    <td>
                        <form action="edit-sm.php" method="post">
                            <input type="hidden" name="sm_edit_id" value="<?php echo $row['sm_id']; ?>">
                            <button type="submit" name="sm_edata_btn" class="btn btn-success"> MARK</button>
                        </form>
                    </td>
                    <td>
                        <form action="../../../forms/code.php" method="POST">
                            <input type="hidden" name="sm_delete_id" value="<?php  echo $row['sm_id']; ?>">
                            <button type="submit" name="sm_delete_btn" class="btn btn-danger"> DELETE</button>
                        </form>
                    </td>
                  </tr>
                </tbody>
                <?php
                } 
            }
            else {
                echo "No Record Found";
            }
            ?>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- /.container-fluid -->

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->
