<?php $page = "Add Ski"; ?>
<?php include_once('../template/admin/header.php'); ?>
<?php include_once('../template/admin/sidebar.php'); ?>
<?php include_once('../template/admin/navbar.php'); ?>
<?php 
	if(isset($_POST['submit'])){
		$valid 				= 1;
		$ski_type 	= clean($_POST['ski_type']);
		$ski_pre 			= clean($_POST['ski_pre']);
		$ski_bar 			= clean($_POST['ski_bar']);

		if(isset($_POST['ski_status'])){
			$ski_status 		= clean($_POST['ski_status']);

			if($ski_status == 'on'){
				$ski_status = 1;
			}else{
				$ski_status = 0;
			}
		}else{
			$ski_status = 0;
		}

		$statement = $conn->prepare('SELECT  * FROM skills WHERE ski_type = ?');
	  	$statement->execute(array($ski_type));
	  	$total = $statement->rowCount();
	  	if( $total > 0 ) {
	    	$valid    = 0;
	    	$errors[] = 'This Skill type is already registered.';
	  	}
		//check if fields empty - code starts
		if(empty($ski_pre)){
		    $valid    = 0;
		    $errors[] = 'Please Enter Skill Presentage';
		}
        if(empty($ski_bar)){
		    $valid    = 0;
		    $errors[] = 'Please Enter Skil bar';
		}

	  //If everthing is OK - code starts
  	  if($valid == 1) {

		//insert the data
		$insert = $conn->prepare("INSERT INTO skills (ski_type, ski_pre,ski_status ,ski_bar ) VALUES(?,?,?,?)");

		$insert->execute(array($ski_type, $ski_pre, $ski_status, $ski_bar));

		//insert the data - code ends
		$_SESSION['success'] = 'Skill has been added successfully!';
	    header('location: skills.php');
	    exit(0);
  	  }
	}
 ?>
<main class="content">
	<div class="container-fluid p-0">
		<h1 class="h3 mb-3"><strong>Add</strong> Skill</h1>
		<form action="" method="POST" enctype="multipart/form-data">
			<div class="row">
				<div class="col-6">
					<div class="card">
						<div class="card-header">
							<h5 class="card-title mb-0">Skill info</h5>
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="mb-3">
										<label class="form-label" for="inputTitle">Skill Title</label>
										<input type="text" class="form-control" id="inputTitle"
											placeholder="Enter Skill Type" name="ski_type">
									</div>
									<div class="mb-3">
										<label class="form-label" for="Skill_desc">Service Description</label>
										<input type="text" rows="4" class="form-control" id="Skill_desc"
											placeholder="Enter Skill Presentage" name="ski_pre">
									</div>
									<div class="mb-3">
										<label class="form-label" for="inputurl">Skill Year</label>
										<input type="text" class="form-control" id="inputurl"
											placeholder="Enter Skill Years" name="ski_bar">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-6">
					<div class="card">
						<div class="card-header">
							<h5 class="card-title mb-0">Skill Status</h5>
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<div class="mt-4">
										<label for="flexSwitchCheckChecked">Enable / Disable</label>
										<div class="form-check form-switch mt-2">
											<input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked"
												checked="" name="ski_status">
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-12 col-lg-12">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col-md-12">
									<button type="submit" name="submit" class="btn btn-primary">Save changes</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>
</main>
<?php include_once('../template/admin/footer.php'); ?>