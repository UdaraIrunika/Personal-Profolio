<?php include_once('../template/admin/header.php'); ?>

<?php include_once('../template/admin/sidebar.php'); ?>

<?php include_once('../template/admin/navbar.php'); ?>
<?php 
	  //Total Subscribers
	  $stmt = $conn->prepare("SELECT * FROM users");
	  $stmt->execute();
	  $users = $stmt->rowCount();

	  //portifolio
	  $stmt = $conn->prepare("SELECT * FROM portifolio");
	  $stmt->execute();
	  $portifolio = $stmt->rowCount();

	  //portifolio
	  $stmt = $conn->prepare("SELECT * FROM portifolio");
	  $stmt->execute();
	  $portifolio = $stmt->rowCount(); 

	  //education
	  $stmt = $conn->prepare("SELECT * FROM education");
	  $stmt->execute();
	  $education = $stmt->rowCount();
?>
<main class="content">
	<div class="container-fluid p-0">
		<h1 class="h3 mb-3"> Dashboard</h1>
		<div class="row">
			<div class="col-xl-6 col-xxl-5 d-flex">
				<div class="w-100">
					
						
						</div>
    </div></div>				
		

	 <!-- ADMIN Card Example -->
	 <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Registered Admin</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">
              <?php
                 $connection = mysqli_connect("localhost","root","","profilo");
				 $query = "SELECT user_id FROM users ORDER BY user_id";  
				 $query_run = mysqli_query($connection, $query);
				 $row = mysqli_num_rows($query_run);
                echo '<h4> Total Admin: '.$row.'</h4>';
              ?>
              </div>
            </div>
            <div class="col-auto">
            <i class="fa-solid fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

	<!-- Education Card Example -->
	<div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Education</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">
              <?php
                 $connection = mysqli_connect("localhost","root","","profilo");
				 $query = "SELECT education_id FROM education ORDER BY education_id";  
				 $query_run = mysqli_query($connection, $query);
				 $row = mysqli_num_rows($query_run);
                echo '<h4> Total Educaton: '.$row.'</h4>';
              ?>
              </div>
            </div>
            <div class="col-auto">
            <i class="fa-solid fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

	<!-- Products Card Example -->
	<div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Product</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">
              <?php
                 $connection = mysqli_connect("localhost","root","","profilo");
				 $query = "SELECT portifolio_id FROM portifolio ORDER BY portifolio_id";  
				 $query_run = mysqli_query($connection, $query);
				 $row = mysqli_num_rows($query_run);
                echo '<h4> Total Producats: '.$row.'</h4>';
              ?>
              </div>
            </div>
            <div class="col-auto">
            <i class="fa-solid fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

	<!-- Products Card Example -->
	<div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Skills</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800">
              <?php
                 $connection = mysqli_connect("localhost","root","","profilo");
				 $query = "SELECT ski_id FROM skills ORDER BY ski_id";  
				 $query_run = mysqli_query($connection, $query);
				 $row = mysqli_num_rows($query_run);
                echo '<h4> Total Skiils: '.$row.'</h4>';
              ?>
              </div>
            </div>
            <div class="col-auto">
            <i class="fa-solid fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>


<!-- 
	<div class="col-xl-6 col-xxl-7">
				<div class="card flex-fill w-100">
					<div class="card-header">

						<h5 class="card-title mb-0">Recent Movement</h5>
					</div>
					<div class="card-body py-3">
						<div class="chart chart-sm">
							<canvas id="chartjs-dashboard-line"></canvas>
						</div>
					</div>
				</div>
			</div>
		</div> -->





</main>
<?php include_once('../template/admin/footer.php'); ?>
<?php 
		$stmt =  $conn->prepare("SELECT count(*) as total, MONTHNAME(user_date_created) as month FROM users GROUP BY MONTH(user_date_created)");
		$stmt->execute();
	  	$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
	 
	  	//print_r($users);
	  	$month = array();
	  	$total = array();
	  	foreach ($users as $key => $value) {
	  		$month[] = $value['month'];
	  		$total[] = $value['total'];
	  	}
	  	$month = "'". implode("','", $month)."'";
	  	$total = implode(', ', $total);
 ?>
<script>
	document.addEventListener("DOMContentLoaded", function () {
		"use strict";
		var ctx = document.getElementById("chartjs-dashboard-line").getContext("2d");
		var gradient = ctx.createLinearGradient(0, 0, 0, 225);
		gradient.addColorStop(0, "rgba(215, 227, 244, 1)");
		gradient.addColorStop(1, "rgba(215, 227, 244, 0)");
		// Line chart
		new Chart(document.getElementById("chartjs-dashboard-line"), {
			type: "line",
			data: {
				labels: [ < ? php echo clean($month); ? > ],
				datasets: [{
					label: "Users",
					fill: true,
					backgroundColor: gradient,
					borderColor: window.theme.primary,
					data: [ < ? php echo clean($total); ? > ]
				}]
			},
			options: {
				maintainAspectRatio: false,
				legend: {
					display: false
				},
				tooltips: {
					intersect: false
				},
				hover: {
					intersect: true
				},
				plugins: {
					filler: {
						propagate: false
					}
				},
				scales: {
					xAxes: [{
						reverse: true,
						gridLines: {
							color: "rgba(0,0,0,0.0)"
						}
					}],
					yAxes: [{
						ticks: {
							stepSize: 1000
						},
						display: true,
						borderDash: [3, 3],
						gridLines: {
							color: "rgba(0,0,0,0.0)"
						}
					}]
				}
			}
		});
	});
</script>