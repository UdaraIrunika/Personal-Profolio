<?php
include("includes/header.php");
?>








<!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">
        <div class="section-title">
          <h2>Portfolio</h2>
          <p>WE HAVE DIFERENT PRODUCTS YOU CAN WATCH THAT PRODUCTS USING THIS AREA</p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">APP</li>
              <li data-filter=".filter-card">CARD</li>
              <li data-filter=".filter-web">WEB</li>
              <li data-filter=".filter-logo">LOGO</li>
              <li data-filter=".filter-banner">BANNER</li>
              <li data-filter=".filter-ytbanner">YT BANNER</li>
              <li data-filter=".filter-fbpost">FB POST</li>
              <li data-filter=".filter-thankscard">THANKS CARD</li>
              <li data-filter=".filter-webadminpannel">WEB DESIGN</li>
              <li data-filter=".filter-webdesign">WEB ADMIN PANNEL DEVELOPED</li>
              <li data-filter=".filter-physicalysellingitems">PHISYCLE SELING ITEMS</li>
              
            </ul>
          </div>
        </div>
        <?php
        $connection = mysqli_connect("localhost","id21850012_profilo","Irunikazoysa12#","id21850012_profilo");
        $query = "SELECT * FROM portifolio ORDER BY portifolio_id DESC";
        $query_run = mysqli_query($connection, $query);
  ?>
  <?php
            if(mysqli_num_rows($query_run) > 0)        
            {
                while($row = mysqli_fetch_assoc($query_run))
                {
            ?>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-4 col-md-6 portfolio-item filter-<?php echo $row['portifolio_category'];?>">
            <div class="portfolio-wrap">
              <h3 align="center"><?php echo $row['portifolio_title']; ?></h3>
              <img src="pro/storage/portifolio/<?php echo $row['portifolio_photo']; ?>" class="img-fluid" alt="">

              <div class="portfolio-links">
                <p><?php echo $row['portifolio_desc']; ?></p>
                <a href="pro/storage/portifolio/<?php echo $row['portifolio_photo']; ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 1"><i class="bx bx-plus"></i></a>
                <a href="https://<?php echo $row['portifolio_url']; ?>" title="More Details"><i class="bx bx-link"></i></a>
              </div>
              </div>
              </div>
              <?php
  } 
}
else {
    echo "No Record Found";
}
?>
        
      </div>
    </section><!-- End Portfolio Section -->













<?php
include("includes/script.php");
?>
 