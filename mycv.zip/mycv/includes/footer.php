
  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>D.UDARA IRUNKA DE ZOYSA</span></strong>
      </div>
      <div class="credits">
        Designed by <a href="https://bootstrapmade.com/">D.UDARA IRUNKA DE ZOYSA</a>
      </div>
    </div>
  </footer><!-- End  Footer -->

